The .scss (Sass) files are only available in the pro version.
You can buy it from: https://bootstrapmade.com/iportfolio-bootstrap-portfolio-websites-template/